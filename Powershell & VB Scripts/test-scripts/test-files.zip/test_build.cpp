#include <iostream>
#include <string>
#include <vector>

int main() {
    std::cout << "==================================" << std::endl;
    std::cout << "  Build Environment Test" << std::endl;
    std::cout << "==================================" << std::endl;
    
    // Compiler detection
    std::cout << "\nCompiler Information:" << std::endl;
    
#if defined(_MSC_VER)
    std::cout << "  Compiler: MSVC" << std::endl;
    std::cout << "  Version: " << _MSC_VER << std::endl;
    #if defined(__clang__)
        std::cout << "  Frontend: Clang-cl" << std::endl;
    #endif
#elif defined(__clang__)
    std::cout << "  Compiler: Clang" << std::endl;
    std::cout << "  Version: " << __clang_major__ << "." 
              << __clang_minor__ << "." << __clang_patchlevel__ << std::endl;
#elif defined(__GNUC__)
    std::cout << "  Compiler: GCC" << std::endl;
    std::cout << "  Version: " << __GNUC__ << "." 
              << __GNUC_MINOR__ << "." << __GNUC_PATCHLEVEL__ << std::endl;
#endif

    // Platform detection
    std::cout << "\nPlatform Information:" << std::endl;
#if defined(_WIN32)
    std::cout << "  Platform: Windows" << std::endl;
    #if defined(_WIN64)
        std::cout << "  Architecture: x64" << std::endl;
    #else
        std::cout << "  Architecture: x86" << std::endl;
    #endif
#elif defined(__linux__)
    std::cout << "  Platform: Linux" << std::endl;
#endif

    // CRT detection
    std::cout << "\nRuntime Library:" << std::endl;
#if defined(_MSC_VER)
    #if defined(_DLL)
        std::cout << "  CRT: MSVC Dynamic CRT" << std::endl;
    #else
        std::cout << "  CRT: MSVC Static CRT" << std::endl;
    #endif
#elif defined(__MINGW32__) || defined(__MINGW64__)
    std::cout << "  CRT: MinGW/UCRT" << std::endl;
#endif

    // C++ Standard
    std::cout << "\nC++ Standard:" << std::endl;
    std::cout << "  __cplusplus: " << __cplusplus << std::endl;
#if __cplusplus >= 202002L
    std::cout << "  Standard: C++20 or later" << std::endl;
#elif __cplusplus >= 201703L
    std::cout << "  Standard: C++17" << std::endl;
#elif __cplusplus >= 201402L
    std::cout << "  Standard: C++14" << std::endl;
#endif

    // Test some C++17 features
    std::cout << "\nTesting C++17 Features:" << std::endl;
    std::vector<std::string> items = {"Windows", "MSYS2", "CMake", "Ninja"};
    std::cout << "  Vector contents: ";
    for (const auto& item : items) {
        std::cout << item << " ";
    }
    std::cout << std::endl;

    std::cout << "\n==================================" << std::endl;
    std::cout << "  Test completed successfully!" << std::endl;
    std::cout << "==================================" << std::endl;
    
    return 0;
}
