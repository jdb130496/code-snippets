# ======================================================
# Test Script 2: MSYS2 Clang + CMake + Ninja
# ======================================================

Write-Host "`n======================================================" -ForegroundColor Cyan
Write-Host "  TEST 2: MSYS2 Clang + CMake + Ninja" -ForegroundColor Cyan
Write-Host "======================================================`n" -ForegroundColor Cyan

# Switch to MSYS2 Clang environment
Write-Host "Setting up MSYS2 Clang environment..." -ForegroundColor Yellow
use-clang-msys

# Create build directory
$buildDir = "build-msys2-clang"
if (Test-Path $buildDir) {
    Write-Host "Cleaning previous build directory..." -ForegroundColor Yellow
    Remove-Item -Recurse -Force $buildDir
}
New-Item -ItemType Directory -Path $buildDir | Out-Null

# Configure with CMake (using MSYS2 CMake)
Write-Host "`nConfiguring with CMake (MSYS2 Clang + Ninja)..." -ForegroundColor Yellow
Push-Location $buildDir
cmake-msys .. -DCMAKE_BUILD_TYPE=Release

if ($LASTEXITCODE -ne 0) {
    Write-Host "`nCMake configuration FAILED!" -ForegroundColor Red
    Pop-Location
    exit 1
}

# Build with Ninja
Write-Host "`nBuilding with Ninja..." -ForegroundColor Yellow
cmake-msys --build . --config Release

if ($LASTEXITCODE -ne 0) {
    Write-Host "`nBuild FAILED!" -ForegroundColor Red
    Pop-Location
    exit 1
}

# Run the test executable
Write-Host "`nRunning test executable..." -ForegroundColor Yellow
Write-Host "========================================" -ForegroundColor Green
.\test_build.exe
Write-Host "========================================" -ForegroundColor Green

Pop-Location

Write-Host "`n✓ TEST 2 PASSED: MSYS2 Clang build successful!" -ForegroundColor Green
Write-Host "  Build directory: $buildDir" -ForegroundColor Gray
Write-Host "  Executable: $buildDir\test_build.exe`n" -ForegroundColor Gray
